import pandas as pd

#5K TRAIN DATA SET

# In[58]:

df_train_data = pd.read_csv('income.train.5k.csv')
df_train_data

# In[59]:

positive_label_train = df_train_data[df_train_data["target"] == ">50K"]
positive_train_pct = len(positive_label_train)/len(df_train_data)*100
print(f'What percentage of the training data has a positive label (>50K)?: {round(positive_train_pct, 2)}%')

# In[60]:

# DEV DATA SET

# In[63]:

df_dev_data = pd.read_csv('income.dev.csv')
df_dev_data

# In[64]:

positive_label_dev = df_dev_data[df_dev_data["target"] == ">50K"]
positive_dev_pct = len(positive_label_dev)/len(df_dev_data)*100
print(f'What percentage of the development data has a positive label (>50K)?: {round(positive_dev_pct, 2)}%')

# In[66]:

min_age_train = df_train_data['age'].min()
print(f'Youngest age in the training data is {min_age_train}')

# In[67]:

max_age_train = df_train_data['age'].max()
print(f'Oldest age in the training data is {max_age_train}')

# In[68]:

min_hours_train = df_train_data['hours'].min()
print(f'People in the training set work at least {min_hours_train} hours per week.')

# In[69]:

max_hours_train = df_train_data['hours'].max()
print(f'People in the training set work at most {max_hours_train} hours per week.')

