#!/usr/bin/env python
# coding: utf-8

# In[68]:


import pandas as pd
import numpy as np
from sklearn.preprocessing import OneHotEncoder
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
import time


# In[69]:


df_train_data = pd.read_csv('income.train.5k.csv')
df_dev_data = pd.read_csv('income.dev.csv')
df_test_data = pd.read_csv('income.test.blind.csv')


# In[70]:


#Binarization in Pandas


# In[71]:


encoded_data_train = pd.get_dummies(df_train_data, columns=["age", "sector", "edu", "marriage", "occupation", "race", "sex", "hours", "country"], dtype = int)
encoded_data_train


# In[72]:


#Binarization in Scikit-Learn


# In[73]:


x_data_sklearn_train = df_train_data.drop(["id", "target"], axis=1)
y_data_sklearn_train = df_train_data[["target"]]
y_data_sklearn_train = y_data_sklearn_train.values.reshape(-1,)
x_data_sklearn_dev = df_dev_data.drop(["id", "target"], axis=1)
y_data_sklearn_dev = df_dev_data[["target"]]
x_data_sklearn_test = df_test_data.drop(["id"], axis=1)


# In[74]:


encoder = OneHotEncoder(sparse_output=False, handle_unknown='ignore')


# In[75]:


encoder.fit(x_data_sklearn_train, y_data_sklearn_train)


# In[76]:


x_encoded_train = encoder.transform(x_data_sklearn_train)
x_encoded_dev = encoder.transform(x_data_sklearn_dev)
x_encoded_test = encoder.transform(x_data_sklearn_test)


# In[77]:


knn = KNeighborsClassifier(n_neighbors=67)


# In[78]:


knn.fit(x_encoded_train, y_data_sklearn_train)


# In[79]:


y_train_pred = knn.predict(x_encoded_train)
y_dev_pred = knn.predict(x_encoded_dev)
train_accuracy = accuracy_score(y_data_sklearn_train, y_train_pred)
dev_accuracy = accuracy_score(y_data_sklearn_dev, y_dev_pred)
print(f"Training Accuracy: {train_accuracy}")
print(f"Development Accuracy: {dev_accuracy}")


# In[83]:


x_train_bin = x_encoded_train
y_train = y_data_sklearn_train
x_dev_bin = x_encoded_dev
y_dev = y_data_sklearn_dev
x_test_bin = x_encoded_test


# In[85]:


results = []
with open("k1to100_part2.txt", "w") as file:
    for k in range(1, 100, 2):  # Odd numbers only
        
        start_time = time.time() #start time
        
        knn = KNeighborsClassifier(n_neighbors=k) #knn classifier and fitting
        knn.fit(x_train_bin, y_train)

        y_train_pred = knn.predict(x_train_bin) #train data predictions and accuracy calc
        train_accuracy = accuracy_score(y_train, knn.predict(x_train_bin))
        train_error = 100 - train_accuracy * 100
        train_positive_rate = (y_train_pred == '>50K').mean() * 100

        y_dev_pred = knn.predict(x_dev_bin) #dev data predictions and accuracy calc
        dev_accuracy = accuracy_score(y_dev, knn.predict(x_dev_bin))
        dev_error = 100 - dev_accuracy * 100
        dev_positive_rate = (y_dev_pred == '>50K').mean() * 100

        running_speed = time.time() - start_time #stop timer
        
        results.append((
            k, train_accuracy, train_error, dev_accuracy, dev_error,
            train_positive_rate, dev_positive_rate, running_speed
        ))
        
        file.write(f"k={k} train_err {100 - train_accuracy * 100:.1f}% (+:{train_positive_rate:.1f}%) dev_err {100 - dev_accuracy * 100:.1f}% (+:{dev_positive_rate:.1f}%) running_speed {running_speed:.2f}s\n")
        print(f"k={k}  train_err: {round(train_error, 2)}% (+:{round(train_positive_rate, 2)}%) dev_err: {round(dev_error, 2)}% (+:{round(dev_positive_rate, 2)}%) running speed: {round(running_speed, 2)}s")

accuracy_df = pd.DataFrame(results, columns=[
    'K Value', 'Training Accuracy', 'Training Error', 'Dev Accuracy', 'Dev Error',
    'Training Positive Rate', 'Dev Positive Rate', 'Running Speed'
])
best_k = accuracy_df['Dev Accuracy'].idxmax() * 2 + 1  # Adjusted for odd k values
print(f"Best k value: {best_k}")

test_predictions = knn.predict(x_test_bin)
df_test_data['target'] = test_predictions
df_test_data.to_csv('income.test.predicted_part2.csv', index=False)

print("Predictions have been added to the test set and a new CSV file has been created.")


# In[82]:


len(X_train_bin[0])


# In[ ]:




