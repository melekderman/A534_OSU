#!/usr/bin/env python
# coding: utf-8

# In[1]:


get_ipython().system('ls')


# In[2]:


get_ipython().system('grep -c "" income.train.5k.csv')


# In[3]:


get_ipython().system('grep -c ">50K" income.train.5k.csv')


# In[5]:


positive_train = 1251/5001
positive_train


# In[6]:


get_ipython().system('grep -c "" income.dev.csv')


# In[7]:


get_ipython().system('grep -c ">50K" income.dev.csv')


# In[8]:


positive_dev = 236/1001
positive_dev


# In[9]:


get_ipython().system('cat income.train.5k.csv | tail -n +2 |sort -t, -nk2 | head -1')


# In[ ]:




