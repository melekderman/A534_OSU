#!/usr/bin/env python
# coding: utf-8

# In[11]:


import pandas as pd


# In[13]:


df_E = pd.read_csv('income.test.predicted_part4_euclidean.csv')


# In[15]:


df_E


# In[63]:


positive_E = len(df_E[df_E['target'] == '>50K'])
positive_E


# In[65]:


total_E = len(df_E)
total_E


# In[67]:


pos_ratio_E = positive_E * 100/ total_E
print(f"Positive Ratio of Euclidean Distance is {pos_ratio_E} %")


# In[69]:


df_M = pd.read_csv('income.test.predicted_part4_manhattan.csv')
df_M


# In[71]:


positive_M = len(df_M[df_M['target'] == '>50K'])
positive_M


# In[73]:


total_M = len(df_M)
total_M


# In[61]:


pos_ratio_M = positive_M * 100 / total_M
print(f"Positive Ratio of Manhattan Distance is {pos_ratio_M} %")


# In[ ]:




