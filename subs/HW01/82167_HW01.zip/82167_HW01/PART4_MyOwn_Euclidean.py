import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler, OneHotEncoder
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
from sklearn.compose import ColumnTransformer
from collections import Counter

df_train_data = pd.read_csv('income.train.5k.csv')
df_dev_data = pd.read_csv('income.dev.csv')
df_test_data = pd.read_csv('income.test.blind.csv')

x_data_sklearn_train = df_train_data.drop(["target"], axis=1)
y_data_sklearn_train = df_train_data[["target"]]
y_data_sklearn_train = y_data_sklearn_train.values.reshape(-1,)
x_data_sklearn_dev = df_dev_data.drop(["target"], axis=1)
y_data_sklearn_dev = df_dev_data[["target"]]
x_data_sklearn_test = df_test_data.drop(["id"], axis=1)

num_processor = MinMaxScaler(feature_range=(0,2))
cat_processor = OneHotEncoder(sparse_output=False, handle_unknown='ignore')

preprocessor = ColumnTransformer([
    ('num', num_processor, ['age', 'hours']),
    ('cat', cat_processor, ['sector', 'edu', 'marriage', 'occupation', 'race', 'sex', 'country'])
])
preprocessor.fit(x_data_sklearn_train)                     

x_train_bin = preprocessor.transform(x_data_sklearn_train)
x_dev_bin = preprocessor.transform(x_data_sklearn_dev)
x_test_bin = preprocessor.transform(x_data_sklearn_test)

y_train = y_data_sklearn_train
y_dev = y_data_sklearn_dev

def compute_distance_matrix(x_train, x_test):
    distances = np.sqrt(np.sum((x_train[:, np.newaxis] - x_test) ** 2, axis=2))
    return distances

def k_nn_predict(x_train, y_train, x_test, k):
    # Compute distances
    distances = compute_distance_matrix(x_train, x_test)
    predictions = []

    for dist in distances.T:
        nearest_neighbor_ids = np.argpartition(dist, k)[:k]
        k_nearest_labels = y_train[nearest_neighbor_ids]
        most_common = Counter(k_nearest_labels).most_common(1)[0][0]
        predictions.append(most_common)

    return np.array(predictions)

def calculate_accuracy(y_true, y_pred):
    return accuracy_score(y_true, y_pred)

results = []
with open("k1to100.txt_part4_euclidean.txt", "w") as file:
    for k in range(1, 100, 2):
        y_train_pred = k_nn_predict(x_train_bin, y_train, x_train_bin, k)
        train_accuracy = calculate_accuracy(y_train, y_train_pred)
        train_error = 100 - train_accuracy * 100
        train_positive_rate = (y_train_pred == '>50K').mean() * 100

        y_dev_pred = k_nn_predict(x_train_bin, y_train, x_dev_bin, k)
        dev_accuracy = calculate_accuracy(y_dev, y_dev_pred)
        dev_error = 100 - dev_accuracy * 100
        dev_positive_rate = (y_dev_pred == '>50K').mean() * 100

        results.append((k, train_accuracy, train_error, dev_accuracy, dev_error))
        file.write(f"k={k}  train_err: {round(train_error, 2)}% (+:{round(train_positive_rate, 2)}%) dev_err: {round(dev_error, 2)}% (+:{round(dev_positive_rate, 2)}%)\n")
              
        print(f"k={k}  train_err: {round(train_error, 2)}% (+:{round(train_positive_rate, 2)}%) dev_err: {round(dev_error, 2)}% (+:{round(dev_positive_rate, 2)}%)")

accuracy_df = pd.DataFrame(results, columns=['K Value', 'Training Accuracy','Training Error', 'Dev Accuracy', 'Dev Error'])

print(accuracy_df)

best_k = accuracy_df['Dev Accuracy'].idxmax() * 2 + 1
print(f"Best k value: {best_k}")

test_predictions = k_nn_predict(x_train_bin, y_train, x_test_bin, best_k)
df_test_data['target'] = test_predictions
df_test_data.to_csv('income.test.predicted_part4_euclidean.csv', index=False)
print("Predictions have been added to the test set and a new CSV file has been created.")
