#!/usr/bin/env python
# coding: utf-8

# In[46]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df_dev_error = pd.read_csv('C:/Users/drmn_/Desktop/AI534/hw1/dev_error.csv')

k = list(range(1, 101, 2))
df_naive = df_dev_error['naive']
df_smart = df_dev_error['smart']
df_smart_scaling = df_dev_error['smart_w_scaling']

plt.figure(figsize=(10, 6))
plt.plot(k, df_naive, label='Naive', linestyle='-', color='darkorange')
plt.plot(k, df_smart, label='Smart', linestyle='--', color='orangered')
plt.plot(k, df_smart_scaling, label='Smart + Scaling', linestyle='-.', color='teal')

plt.xlabel('k')
plt.ylabel('Dev Error Rate (%)')
plt.legend()

plt.grid(True)
plt.savefig('part7.png') 
plt.show()





# In[ ]:




